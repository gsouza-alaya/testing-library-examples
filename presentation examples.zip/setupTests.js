import Vue from "vue";
import VueCompilerDOM from "@vue/compiler-dom";
global.Vue = Vue;
global.VueCompilerDOM = VueCompilerDOM;
